# Better With Mods

Documentation for the Better With Mods mod.

Visit our main site at [BetterWithMods.com](https://www.betterwithmods.com)

Join us on [discord](https://discord.betterwithmods.com)

* [English](en_us/index.md)
* [简体中文](zh_cn/index.md)

# 微芯片

![Not the edible ones.](oredict:oc:circuitChip1)

微芯片在合成中很重要.他们有不同的型号，对应不同型号的产物 

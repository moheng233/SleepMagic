# 控制单元

![With built-in cruise control.](oredict:oc:materialCU)

高级电路的合成单元，如 [CPU](cpu1.md).

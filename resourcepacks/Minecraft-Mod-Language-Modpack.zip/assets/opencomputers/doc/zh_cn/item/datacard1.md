# 数据卡

![Contrary to popular belief, it does not store data.](oredict:oc:dataCard1)

一种提供了多个难以在架构上实现，或者是在那里跑的很慢的算法的卡，可以看作是协处理器，用于处理hash，压缩等操作

注意每次调用处理的数据有限,并且很吃能量.

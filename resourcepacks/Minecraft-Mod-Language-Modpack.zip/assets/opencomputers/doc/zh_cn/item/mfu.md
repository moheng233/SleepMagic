# MFU

![You will never know the true meaning of this acronym.](oredict:oc:mfu)

此升级提供了一个远程的[适配器](../block/adapter.md).在任意方块边上蹲下,并右键,都会把它绑定到特定位置.然后放到附近的适配器里面(这个附近很有限).适配器就会像刚好在
你绑定的那个方块边上放着那样工作(一般的适配器要挨着,这里隔了一点距离)!
记住，保持远程适配器链接需要能量.

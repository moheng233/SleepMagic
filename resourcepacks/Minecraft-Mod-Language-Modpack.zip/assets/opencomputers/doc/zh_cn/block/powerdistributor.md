# Power Distributor

![Power to the masses.](oredict:oc:powerDistributor)

能源分配器能够将一个共享能源池(如[电容](capacitor.md))的能源分配出去, 使得子网络能够在不暴露元件的情况下分享能源
它的作用是负载均衡，因此你会发现每个子网的能量供应都“差不多”